#include<stdio.h>
int main()
{
    int a,b;
    a=90;
    b=50;
    printf("\n add= %d",a+b);
    printf("\n sub= %d",a-b );
    printf("\n multiply= %d",a*b);
    printf("\n divide= %d",a/b);
    return 0;
}